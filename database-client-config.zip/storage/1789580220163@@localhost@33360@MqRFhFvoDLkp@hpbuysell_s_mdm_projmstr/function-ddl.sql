CREATE OR REPLACE FUNCTION hpbuysell_s_mdm_projmstr.hpbuysell_mdm_projmstr_projectmaster_func_change()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
    DECLARE
        entity_name TEXT := 'hpbuysell.mdm.projmstr.ProjectMaster';
        entity_key TEXT;
        object_id TEXT;
        user_id TEXT := coalesce(current_setting('cap.applicationuser', true), 'anonymous');
        transaction_id BIGINT := txid_current();
        
        
    BEGIN
        
        DECLARE
            rec RECORD;
        BEGIN
            IF NOT (COALESCE(current_setting('ct.skip', true), 'false') != 'true' AND COALESCE(current_setting('ct.skip_entity.hpbuysell_mdm_projmstr_ProjectMaster', true), 'false') != 'true') THEN
                RETURN NULL;
            END IF;

            IF (TG_OP = 'DELETE') THEN
                rec := OLD;
            ELSE
                rec := NEW;
            END IF;

            entity_key := LENGTH(rec.wbsElement::TEXT) || ',' || rec.wbsElement::TEXT || ';' || LENGTH(rec.salesDocument::TEXT) || ',' || rec.salesDocument::TEXT || ';' || LENGTH(rec.customer::TEXT) || ',' || rec.customer::TEXT || ';' || LENGTH(rec.supplierCode::TEXT) || ',' || rec.supplierCode::TEXT || ';' || LENGTH(rec.hpPartNumber::TEXT) || ',' || rec.hpPartNumber::TEXT;
            object_id := entity_key;

            IF (TG_OP = 'INSERT') THEN
                
                INSERT INTO sap_changelog_changes
            (ID, PARENT_ID, ATTRIBUTE, VALUECHANGEDFROM, VALUECHANGEDTO, VALUECHANGEDFROMLABEL, VALUECHANGEDTOLABEL, ENTITY, ENTITYKEY, OBJECTID, CREATEDAT, CREATEDBY, VALUEDATATYPE, MODIFICATION, TRANSACTIONID)
            SELECT
                gen_random_uuid(),
                NULL,
                attribute,
                valueChangedFrom,
                valueChangedTo,
                valueChangedFromLabel,
                valueChangedToLabel,
                entity_name,
                entity_key,
                object_id,
                now(),
                user_id,
                valueDataType,
                'create',
                transaction_id
            FROM (
            SELECT 'EDIBTPMigrationStartDate' AS attribute, NULL AS valueChangedFrom, NEW.EDIBTPMigrationStartDate::TEXT AS valueChangedTo, NULL AS valueChangedFromLabel, NULL AS valueChangedToLabel, 'cds.Date' AS valueDataType WHERE (NEW.EDIBTPMigrationStartDate IS NOT NULL) AND COALESCE(current_setting('ct.skip_element.hpbuysell_mdm_projmstr_ProjectMaster.EDIBTPMigrationStartDate', true), 'false') != 'true'
            ) AS changes;
            ELSIF (TG_OP = 'UPDATE') THEN
                
                INSERT INTO sap_changelog_changes
            (ID, PARENT_ID, ATTRIBUTE, VALUECHANGEDFROM, VALUECHANGEDTO, VALUECHANGEDFROMLABEL, VALUECHANGEDTOLABEL, ENTITY, ENTITYKEY, OBJECTID, CREATEDAT, CREATEDBY, VALUEDATATYPE, MODIFICATION, TRANSACTIONID)
            SELECT
                gen_random_uuid(),
                NULL,
                attribute,
                valueChangedFrom,
                valueChangedTo,
                valueChangedFromLabel,
                valueChangedToLabel,
                entity_name,
                entity_key,
                object_id,
                now(),
                user_id,
                valueDataType,
                'update',
                transaction_id
            FROM (
            SELECT 'EDIBTPMigrationStartDate' AS attribute, OLD.EDIBTPMigrationStartDate::TEXT AS valueChangedFrom, NEW.EDIBTPMigrationStartDate::TEXT AS valueChangedTo, NULL AS valueChangedFromLabel, NULL AS valueChangedToLabel, 'cds.Date' AS valueDataType WHERE (NEW.EDIBTPMigrationStartDate IS DISTINCT FROM OLD.EDIBTPMigrationStartDate) AND COALESCE(current_setting('ct.skip_element.hpbuysell_mdm_projmstr_ProjectMaster.EDIBTPMigrationStartDate', true), 'false') != 'true'
            ) AS changes;
            ELSIF (TG_OP = 'DELETE') THEN
                
                DELETE FROM sap_changelog_changes WHERE entity = 'hpbuysell.mdm.projmstr.ProjectMaster' AND entitykey = LENGTH(OLD.wbsElement::TEXT) || ',' || OLD.wbsElement::TEXT || ';' || LENGTH(OLD.salesDocument::TEXT) || ',' || OLD.salesDocument::TEXT || ';' || LENGTH(OLD.customer::TEXT) || ',' || OLD.customer::TEXT || ';' || LENGTH(OLD.supplierCode::TEXT) || ',' || OLD.supplierCode::TEXT || ';' || LENGTH(OLD.hpPartNumber::TEXT) || ',' || OLD.hpPartNumber::TEXT;
            INSERT INTO sap_changelog_changes
            (ID, PARENT_ID, ATTRIBUTE, VALUECHANGEDFROM, VALUECHANGEDTO, VALUECHANGEDFROMLABEL, VALUECHANGEDTOLABEL, ENTITY, ENTITYKEY, OBJECTID, CREATEDAT, CREATEDBY, VALUEDATATYPE, MODIFICATION, TRANSACTIONID)
            SELECT
                gen_random_uuid(),
                NULL,
                attribute,
                valueChangedFrom,
                valueChangedTo,
                valueChangedFromLabel,
                valueChangedToLabel,
                entity_name,
                entity_key,
                object_id,
                now(),
                user_id,
                valueDataType,
                'delete',
                transaction_id
            FROM (
            SELECT 'EDIBTPMigrationStartDate' AS attribute, OLD.EDIBTPMigrationStartDate::TEXT AS valueChangedFrom, NULL AS valueChangedTo, NULL AS valueChangedFromLabel, NULL AS valueChangedToLabel, 'cds.Date' AS valueDataType WHERE (OLD.EDIBTPMigrationStartDate IS NOT NULL) AND COALESCE(current_setting('ct.skip_element.hpbuysell_mdm_projmstr_ProjectMaster.EDIBTPMigrationStartDate', true), 'false') != 'true'
            ) AS changes;
            END IF;
        END;
        RETURN NULL;
    END;
    $function$
