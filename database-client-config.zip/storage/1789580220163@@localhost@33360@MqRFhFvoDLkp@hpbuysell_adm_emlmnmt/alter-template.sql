-- change column type
ALTER TABLE cds_model 
    ALTER COLUMN csn TYPE text;
-- change column name
ALTER TABLE cds_model 
    RENAME COLUMN csn TO csn;
-- Change column comment
COMMENT ON COLUMN cds_model.csn IS 'comment';